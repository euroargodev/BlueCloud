The Ocean Regimes Indicator computation have been developed in to 2 Jupyter notebooks : a model development notebook (ModelDevelopment_OceanRegimes.ipynb) and a Prediction notebook (PredictandPlot_OceanRegimes.ipynb).

- Development notebooks: it is use to design, optimize and train a model. The output is a trained model that is saved in the models/ folder.

- Prediction notebook : Using a trained model, you can classify the time series of a dataset into the different classes . You can used the model developed in the first notebook or one of the pretrained models available in the models/ folder (see list below). The output of this notebook are the figures, saved in the figures/ folder and the dataset including the prediction variables.

List of pretrained models
######################################################################
# 1. Chlorophyll model (EX_modelOR_mediterranean_chl_2019_k7.sav) 
Training dataset : daily Chlorophyll-a fields of OCEANCOLOUR_GLO_CHL_L4_REP_OBSERVATIONS_009_082 product
Spatial selection : Mediterranean sea
Temporal selection : year 2019
Variable : Chlorophyll
Number of classes : 7
# 2. Temperature model (EX_modelOR_mediterranean_temp_2019_k8.sav) 
Training dataset : daily field of SST_GLO_SST_L4_NRT_OBSERVATIONS_010_014 product
Spatial selection : Mediterranean sea
Temporal selection : year 2019
Variable : temperature
Number of classes : 8
######################################################################

In this 2 notebooks we propose an example covering the Mediterranean Sea and we use the daily Chlorophyll-a fields of OCEANCOLOUR_GLO_CHL_L4_REP_OBSERVATIONS_009_082 CMEMS product.

You are invited to change the parameters in side the notebooks and to try other geographical extensions or variables.

If you are interested in using SST data you should use another CMEMS dataset : SST_GLO_SST_L4_NRT_OBSERVATIONS_010_014
And change the downloading string in the both notebooks :
bashCommand = 'python -m motuclient -u ' + CMEMS_user + ' -p ' + CMEMS_password + ' -m "http://my.cmems-du.eu/motu-web/Motu" \
-s SST_GLO_SST_L4_NRT_OBSERVATIONS_010_014-TDS -d METOFFICE-GLO-SST-L4-NRT-OBS-SKIN-DIU-FV01.1 \
-x ' + str(geo_extent[0]) + ' -X ' + str(geo_extent[1]) + ' -y ' + str(geo_extent[2]) + ' -Y ' + str(geo_extent[3]) + \
' -t "' + time_extent[0] + '" -T "' + time_extent[1] + \
-v ' + var_name_ds + ' -o datasets -f ' + file_name

We invite the user to follow carefully the instructions  in the notebooks to make the most of them.
