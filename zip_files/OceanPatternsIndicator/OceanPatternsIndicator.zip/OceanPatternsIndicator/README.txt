The Ocean Patterns indicator computation have been developed in to 2 Jupyter notebooks : a Model Development notebook (Develop_PCM_model.ipynb) and a Prediction notebook (predict_PCMlabels_and_plot.ipynb).

- Development notebooks: it is use to design, optimize and train a model. The output is a trained model that is saved in the models/ folder.

- Prediction notebook : Using a trained model, you can classify the profiles of a dataset into the different classes . You can used the model developed in the first notebook or one of the pretrained models available in the models/ folder (see list below). The output of this notebook are the figures, saved in the figures/ folder and the dataset including the prediction variables.

List of pretrained models
######################################################################
# 1. Reanalysis model (test_model_mediterranean_temp_2018_k8.nc) 
Training dataset : monthly mean fields of GLOBAL_REANALYSIS_PHY_001_030
Spatial selection : Mediterranean sea
Temporal selection : year 2018
Variable : temperature
Number of classes : 8
# 2. Reanalysis model bio (test_model_mediterranean_chl_2018_k8.nc) 
Training dataset : monthly mean fields of GLOBAL_REANALYSIS_BIO_001_029
Spatial selection : Mediterranean sea
Temporal selection : year 2018
Variable : chlorophyll
Number of classes : 8
# 3. Argo floats model (test_model_Argo_mediterranean_temp_2013_k8.nc) 
Training dataset : Argo profiles
Spatial selection : Mediterranean sea
Temporal selection : year 2013
Variable : temperature
Number of classes : 8
# 4. Argo floats model Atlantic (model_Argo_Atlantic_Mazeetal_temp_sal_k7.nc) 
Training dataset : Argo profiles
Spatial selection : North Atlantic Ocean
Temporal selection : 2000-2014
Variable : temperature and salinity
Number of classes : 8
######################################################################

In this 2 notebooks we propose an example covering the Mediterranean Sea and we use the monthly mean fields of GLOBAL_REANALYSIS_PHY_001_030 CMEMS product.

You are invited to change the parameters inside the notebooks and to try other geographical extensions or variables.

If you are interested in using biological data you should use another CMEMS dataset : GLOBAL_REANALYSIS_BIO_001_029
And change the downloading string in both notebooks :
bashCommand = 'python -m motuclient -u ' + CMEMS_user + ' -p ' + CMEMS_password + ' -m "http://my.cmems-du.eu/motu-web/Motu" \
-s GLOBAL_REANALYSIS_BIO_001_029-TDS -d global-reanalysis-bio-001-029-monthly \
-x ' + str(geo_extent[0]) + ' -X ' + str(geo_extent[1]) + ' -y ' + str(geo_extent[2]) + ' -Y ' + str(geo_extent[3]) + \
' -t "' + time_extent[0] + '" -T "' + time_extent[1] + '" -z 0.0 -Z 2500.0 \
-v ' + var_name_ds + ' -o datasets -f ' + file_name

We invite the user to follow carefully the instructions in the notebooks to make the most of them.
